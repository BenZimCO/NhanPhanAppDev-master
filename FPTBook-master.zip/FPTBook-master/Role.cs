﻿namespace FPTBook;

public class Role
{
    public const string Admin = "ADMIN";
    public const string Owner = "OWNER";
    public const string Customer = "CUSTOMER";
}