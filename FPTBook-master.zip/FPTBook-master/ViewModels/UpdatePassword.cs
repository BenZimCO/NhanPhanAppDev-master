namespace FPTBook.ViewModels.User;

public class UpdatePassword
{
    public string Id { get; set; }
    public string Password { get; set; }
}