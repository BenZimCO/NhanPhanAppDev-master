﻿namespace FPTBook.ViewModels.Category;

public class CategoryCreate
{
    public string Name { get; set; }
}