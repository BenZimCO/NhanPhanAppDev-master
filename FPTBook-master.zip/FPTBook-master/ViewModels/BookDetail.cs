﻿using FPTBook.Models;

public class BookDetail
{
    public Book Book { get; set; }
    public List<Book> Books { get; set; }
}