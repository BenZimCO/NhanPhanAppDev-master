﻿namespace FPTBook.ViewModels;

public class CategoryRequestCreate
{
    public string Name { get; set; }
}