# FPTBook
Design of Database:

![image](https://user-images.githubusercontent.com/84282841/203916516-61b9f943-f239-4860-90ce-5e12a050b3db.png)
